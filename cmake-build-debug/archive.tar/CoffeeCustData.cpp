/* Name: Snailey Dol
Date: 11/13/2022
Section: Connor Christian
Assignment: Module 10: Starbucks - Coffee Customer Rating Data Program
Due Date: 11/13/2022
About this project: equires the proper use of arrays of structures in a program using a top-down approach
Assumptions: N/A
All work below was performed by Snailey Dol */

#include <iostream>
#include <fstream>
#include <string>
#include <vector>
#include <iomanip>

using namespace std;

void analyzeData // It will read the data given
        (
        vector<int>& Status, vector<int>& Method, vector<int> &productRating, vector<int> &priceRating,
        vector<int> &serviceRating
        )
{
    ifstream Data;
    Data.open("StarbucksData.txt"); //contains the data
    if (Data)
    {
        int data1, data2, data3, data4, data5;
        while (Data >> data1>> data2>> data3>> data4>> data5)
        {
            Status.push_back(data1);
            Method.push_back(data2);
            productRating.push_back(data3);
            priceRating.push_back(data4);
            serviceRating.push_back(data5);
        }
        Data.close();
    }
}
void maxRatingByStatus(vector<int>& Status, vector<int> &priceRating) // function to display the data
{
    ofstream OutFile;
    int max0=1, max1=1, max2=1, max3=1;

    for (int i = 0; i < Status.size(); i++)
    {

        if (Status.at(i) == 0 && priceRating.at(i) > max0)
        {
            max0 = priceRating.at(i);
        }
        if (Status.at(i) == 1 && priceRating.at(i) > max1)
        {
            max1 = priceRating.at(i);
        }
        if (Status.at(i) == 2 && priceRating.at(i) > max2)
        {
            max2 = priceRating.at(i);
        }
        if (Status.at(i) == 3 && priceRating.at(i) > max3)
        {
            max3 = priceRating.at(i);
        }
    }
    cout << "Student " << max0 << endl // display the data for student
         << "Self-Employed " << max1 << endl // display the data for Self- Employed
         << "Employed " << max2 << endl // display the data for Employed
         << "Housewife " << max3 << endl; // display the data for Housewife

    OutFile.open("OutputA.txt");

    OutFile << "Student " << max0 << endl
            << "Self-Employed " << max1 << endl
            << "Employed " << max2 << endl
            << "Housewife " << max3 << endl;

    OutFile.close();

}

void avgRatingByMethod(vector<int>& Method, vector<int>& serviceRating) // function to display the data
{
    ofstream OutFile;

    double count0=0, total0=0, avg0,
            count1 = 0, total1 = 0, avg1,
            count2 = 0, total2 = 0, avg2,
            count3 = 0, total3 = 0, avg3,
            count4 = 0, total4 = 0, avg4;

    for (int i = 0; i < Method.size(); i++)
    {
        if (Method[i] == 0)
        {
            count0++;
            total0 += serviceRating[i];
        }
        if (Method[i] == 1)
        {
            count1++;
            total1 += serviceRating[i];
        }
        if (Method[i] == 2)
        {
            count2++;
            total2 += serviceRating[i];
        }
        if (Method[i] == 3)
        {
            count3++;
            total3 += serviceRating[i];
        }
        if (Method[i] == 4)
        {
            count4++;
            total4 += serviceRating[i];
        }
    }

    if (count1 == 0)
    {
        avg1 = 0;
    }
    else
    {
        avg1 = total1 / count1;
    }
    if (count2 == 0)
    {
        avg2 = 0;
    }
    else
    {
        avg2 = total2 / count2;
    }
    if (count3 == 0)
    {
        avg3 = 0;
    }
    else
    {
        avg3 = total3 / count3;
    }
    if (count4 == 0)
    {
        avg4 = 0;
    }
    else
    {
        avg4 = total4 / count4;
    }
    if (count0 == 0)
    {
        avg0 = 0;
    }
    else
    {
        avg0 = total0 / count0;
    }


    cout << fixed << setprecision(2) // sets it to 2 decimal places
         << "Dine In "  << avg0 << endl // display the data for Dine In
         << "Drive-thru " << avg1 << endl // display the data for Drive- thru
         << "Take away " << avg2 << endl // display the data for Take away
         << "Never " << avg3 << endl // display the data for Never
         << "Other " << avg4 << endl; // display the data for Other

    OutFile.open("OutputB.txt");

    OutFile << fixed << setprecision(2)
            << "Dine In " << avg0 << endl
            << "Drive-thru " << avg1 << endl
            << "Take away " << avg2 << endl
            << "Never " << avg3 << endl
            << "Other " << avg4 << endl;

    OutFile.close();
}

int main() // the place where the main function takes place
{
    vector<int> Status;
    vector<int> Method;
    vector<int> priceRating;
    vector<int> serviceRating;
    vector<int> productRating;
    char choice;
    cout << "Starbucks - Coffee Customer Rating Data" << endl // the menu for the program
         << "Options" << endl
         << "A) Display the maximum Price Rating by Status..." << endl
         << "B) Display the average Service Rating by Method..." << endl
         << "Please select option (A-B)..."<< endl;

    cin >> choice; // choose between A and B

    while (choice != 'A' && choice != 'a' && choice != 'B' && choice != 'b') // loop so the user choose A, a, B, or b
    {
        cout << "Invalid option entered" << endl
        << "Please select option (A-B)..."<< endl;
        cin >> choice;
    }

    if (choice == 'A' || choice == 'a')// for when the user choose A/a
    {
        analyzeData(Status, Method, productRating, priceRating, serviceRating);

        maxRatingByStatus(Status, priceRating);
    }
    if (choice == 'B' || choice == 'b') // for when user choose B/b
    {
        analyzeData(Status, Method, productRating, priceRating, serviceRating);

        avgRatingByMethod(Method, serviceRating);
    }

    return 0;
}
